

package ejercicio6_guia7;

//@author pittu

import Entidad.Cafetera;
import Servicio.ServicioCafetera;


public class Ejercicio6_Guia7 {

    public static void main(String[] args) {
        
        ServicioCafetera accion=new ServicioCafetera();
        Cafetera C1=new Cafetera ();
        
        accion.menuCafetera(C1);
        
        
        
        
    }

}
